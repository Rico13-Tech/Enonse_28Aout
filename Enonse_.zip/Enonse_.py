print("............Enonse 28 Aout 2023.........")
def read_file(file_path):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
        return content
    except FileNotFoundError:
        return "Fichye a pa jwenn."

def display_text(content):
    print("\nContents of the file:\n-------------------------------------")
    print(content)

def edit_text(content):
    print("\nCurrent content:\n", content)
    print("Enter the new content (type 'done' on a new line to finish editing):\n")
    modified_lines = []
    while True:
        line = input()
        if line == 'done':
            break
        modified_lines.append(line)
    modified_content = '\n'.join(modified_lines)
    return modified_content

def clean_text(content):
    cleaned_content = content.strip()
    cleaned_content = ' '.join(cleaned_content.split())
    return cleaned_content

def save_text(content, file_path):
    with open(file_path, 'w') as file:
        file.write(content)
    print("\nFile saved successfully.")

print("Welcome to the Text File Editor!\n")

while True:
    print("1. Read Text File")
    print("2. Display Text")
    print("3. Update Text")
    print("4. Clean Text")
    print("5. Save Text")
    print("6. Exit")
    
    choice = input("\nPlease select an option: ")
    
    if choice == '1':
        file_path = input("\nEnter the path to the text file: ")
        content = read_file(file_path)
        if content != "Fichye a pa jwenn.":
            print("\nFile read successfully.")
    
    elif choice == '2':
        if content:
            display_text(content)
        else:
            print("\nPlease read a file first.")
    
    elif choice == '3':
        if content:
            modified_content = edit_text(content)
            cleaned_content = clean_text(modified_content)
            content = cleaned_content
            print("\nText updated successfully.")
        else:
            print("\nPlease read a file first.")
    
    elif choice == '4':
        if content:
            cleaned_content = clean_text(content)
            content = cleaned_content
            print("\nText cleaned successfully.")
        else:
            print("\nPlease read a file first.")
    
    elif choice == '5':
        if content:
            save_text(content, file_path)
        else:
            print("\nPlease read a file first.")
    
    elif choice == '6':
        print("\nExiting the Text File Editor.")
        break
    
    else:
        print("\nInvalid choice. Please select a valid option.")